<?php

/**
 * @package  moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 * @doc https://docs.moodle.org/dev/Message_API
 */

// Allow to declare your plugin as the messaging provider.
 
defined('MOODLE_INTERNAL') || die();

