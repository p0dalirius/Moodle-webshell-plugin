<?php

/**
 * @package  moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 * @doc https://docs.moodle.org/dev/Event_2
 */

namespace moodle_webshell\event;

defined('MOODLE_INTERNAL') || die();


class something_changed extends base {

}
