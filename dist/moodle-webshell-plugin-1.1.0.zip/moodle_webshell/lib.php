<?php

/**
 * @package  moodle_webshell
 * @copyright 2022, Remi GASCOU (Podalirius) <podalirius@protonmail.com>
 * @license MIT
 * @doc https://docs.moodle.org/dev/Plugin_files
 */
 
defined('MOODLE_INTERNAL') || die();

