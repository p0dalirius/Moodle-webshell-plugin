<?php

// Must be included
define('CLI_SCRIPT', true);
